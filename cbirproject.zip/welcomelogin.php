<?php
session_start();
?>

<html>
    <head>
        <style>
            table {
                align-content: center;
    border-collapse: collapse;
    width: 100%;
}

td {
    text-align: center;
    height: 30px;

}
        </style>
        <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float:right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}


</style> <div class="topnav">
                
  <a href="logout.php">LOGOUT</a>
 
   <a href='allimages.php'>SEE ALL IMAGES</a>
   <a href="changedetails.php">CHANGE PASSWORD</a></div>
    </head>
    <body background="ght.png">
                
   <?php
$connection = mysqli_connect("localhost","root","bavya.sri12","project"); 
$sql = "select sno from names";
$result = mysqli_query($connection, $sql); 
?>

        <br><br>
        <table  style='color:white;'>
            <tr>
                <td style='color:white;font-size: 25px'>
                    WELCOME <?php echo $_SESSION['username']; ?>
                </td>
            </tr>
           
        </table>
        <table align='center' style='color:white'>
  <p>
                      <form action="uploadimg.php" method="post" enctype="multipart/form-data">
            <tr>
                <td><h2>select an image to upload:</h2></td>
            </tr>
            <tr>
                <td><input name="image" type="file" style='width:30%;height:100%' ></td>
            </tr>
            
            <tr>
                <td  ><input type="text" name="details" placeholder='detail of image' style='width:30%;height:100%'  requuired></td>
            </tr>
            <tr><td><br></td></tr>
            <tr>
                <td><input type="submit" value="upload" name="insert" style='width:10%;height:100%' ></td>
            </tr>
            
        </form>
             <tr><td><br></td></tr><tr><td><br></td></tr>
    
        <form action="ret.php" method="post" enctype="multipart/form-data">
            <tr>
                <td><h2>enter the details of image to retrieve</h2></td>
            </tr>

            <tr>
               <td><input type="text" name="details" placeholder='detail of image' autocomplete='off'list='p' style='width:50%;height:130%' required></td>
            <datalist id='p'>
                <?php while($row = mysqli_fetch_array($result)) { ?>
            <option value="<?php echo $row['sno']; ?>">
                <?php echo $row['sno']; ?></option>
        <?php } ?>
            </datalist>
            </tr>
            <tr><td><br></td></tr>
            <tr>
                <td><input type="submit" value="get images" style='width:10%;height:100%'></td>
            </tr>
        </form>
    </p>
   
    </table>
    </body>
</html>

