<?php 
session_start();
?>
<?php
$con= mysqli_connect("localhost","root","bavya.sri12","project");
  if(!$con)
      die("connection failed". mysqli_connect_error());

  if(isset($_POST["insert"]))
  {
      $check= getimagesize($_FILES["image"]["tmp_name"]);
      if($check!=FALSE)
      {      
          $details=$_POST["details"];
           $name=$_SESSION["username"].'images';
        $f= addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
         $sqll="insert into $name values('$details','$f');";
         mysqli_query($con, $sqll);
          include 'loginimg.php';
         
      }
      else
         include 'imgfail.php';
  }
    ?>
