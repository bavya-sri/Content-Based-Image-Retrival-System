<?php
session_start();
?>
<html>
    <body>
        <h1 style="text-align: center">WELCOME!<?php echo $_SESSION["username"]; ?></h1>
        <table width="400">
            <form action="upload.php" method="post" enctype="multipart/form-data">
                <tr>
                    <td>
                        select image to upload:<br>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="file" name="image"><br>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="details" required><br>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="upload"><br>
                    </td>
                </tr>
            </form>
        </table>
        <table style="padding-top:0px;padding-left: 401px">
            <tr>
                <td>
                    enter details of image:
                </td>
            </tr>
        </table>
        <table style="padding-left: 802px">
            <tr>
                <td>
                    enter:
                </td>
            </tr>
        </table>
        
            
    </body>
</html>
    
    
