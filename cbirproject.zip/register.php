<html>
    <body>
<?php
$firstname=$_POST["firstname"];
$middlename=$_POST["middlename"];
$lastname=$_POST["lastname"];
$gender=$_POST["gender"];
$location=$_POST["location"];
$email=$_POST["email"];
$username=$_POST["username"];
$password=$_POST["password"];
$conn=new mysqli("localhost","root","bavya.sri12","project");
if($conn->connect_error)
{
    die("connection failed".$conn->connect_error);
}
 else {
     $sqlc="select username,email from user where username='".$username."' or email='$email';";
     $res1=$conn->query($sqlc);
     
     if($res1->num_rows){
     
      include 'register1.html';
        }
    
    else{
        $s=$username.'images';
         $sql="insert into user values('".$firstname."','".$middlename."','".$lastname."','".$gender."','".$location."','".$email."','".$username."','".$password."');";
         if($conn->query($sql)){
             
             $sqli="create table $s(details varchar(2000),image varchar(6000)); ";
             if($conn->query($sqli)){
                 setcookie('email',$email,time()+86400,'/');
                header('location:email.jsp');
                 
             }
         }
    }
 }
?>
    </body>
</html>

