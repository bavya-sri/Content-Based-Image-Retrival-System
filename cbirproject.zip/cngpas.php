<?php
session_start();?>
<?php
$x=$POST['oldpas'];
$name=$_SESSION['username'];
$conn = new mysqli("localhost","root","bavya.sri12","project"); 
$sql = "select password from user where username= '$name'";
$result=$conn->query($sql);
   if($result->num_rows){
       while($row=$result->fetch_assoc()){
           if($x == $row['password']){
               include 'sucpascng.php';
           }else{
               include 'failpascng.php';
           }
       }
}
?>

