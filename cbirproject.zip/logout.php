<?php
session_start();
?>
<?php
session_unset();
session_destroy();
$_SESSION=array();
?>
<html><body background='ght.png'><br><br>
   
    <?php
    include 'relogin.html'; ?>
    </body>
</html>


