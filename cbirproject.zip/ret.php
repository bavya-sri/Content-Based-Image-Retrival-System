<?php
session_start();
?>
<?php $details=$_POST["details"];
?>
<html>
    <head>
        <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float:right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}


</style>
    </head><body>
<title>CBIR</title>
 <div class="topnav">
           
  <a href="logout.php">LOGOUT</a>
  <a href='allimages.php' >SEE ALL IMAGES</a>
  <a href='welcomelogin.php'>HOME</a></div>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-container w3-teal">
<h1><?php echo $details; ?></h1>
</div>
   
</body></html>
 <?php
        $con= mysqli_connect("localhost","root","bavya.sri12","project");
  if(!$con)
      die("connection failed". mysqli_connect_error());
    $details=$_POST["details"];
            $name=$_SESSION["username"].'images';
          $det=explode(" ",$details);
          $i=0;
          foreach ($det as $i){
            $sql="select details,image from $name where details like '%$i%';";
               $result=mysqli_query($con,$sql);
               if(mysqli_num_rows($result)>0){ ?>
                   <html>  <table align='center'><tr><td>
                                   <div class="w3-row-padding w3-margin-top">
<div class="w3-third">
<div class="w3-card"></html>
              <?php   while($row = mysqli_fetch_array($result)){  
                     ?>
                       <html><?php
echo '<img src="data:image/jpeg;base64,'.base64_encode($row["image"]).'" width="400" height="500"/>'; ?> 
<div class="w3-container">
<h4><?php echo $row["details"]; ?></h4>

<?php 
          } ?>
          </div>
</div>
</div>
</div>                          
</html>
          
                       </td></tr></table></html>
           <?php   }} ?>
       


