<?php
session_start();
?>
        <html><head>
     <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float:right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}


</style>

    </head>
    <body>
        <?php
            $username=$_POST["username"];
            $password=$_POST["password"];
            $conn=new mysqli("localhost","root","bavya.sri12","project");
            if($conn->connect_error)
            {
                die("connection failed".$conn->connect_error);
            }
 else {
     $sql="select username,password from user where username='".$username."';";
 
        $dbpass=$conn->query($sql);
        if($dbpass->num_rows)
        {
            while($row=$dbpass->fetch_assoc())
            {
                if($password==$row["password"])
                {
                    $_SESSION["username"]=$_POST["username"];
                    include 'welcomelogin.php';
                }
                else
                {
                    include 'loginpas.html';
                }
            }
 }
 else{
     include 'logindup.html';
 }
                }
 $conn->close();
        ?>
    </body>
</html>

