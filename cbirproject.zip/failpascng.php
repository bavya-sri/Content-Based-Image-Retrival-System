<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
    <script>
         function tes(){
                var x=document.getElementById("newpas").value;
                var y=/^[A-Z]{1}[a-z0-9@#$%^&!]{4,30}[@#$%^&]{1}[a-z0-9@#$%^&!]{0,30}$/;
                if(!x.match(y)){
                    document.getElementById("p1").innerHTML="password should start with capital letter and should contain 1 special letter";
                }}
                 function passcheck(){
                var x=document.getElementById("newpas").value;
                var y=document.getElementById("cnfnewpas").value;
                if(x!==y){
      
                    document.getElementById("p2").innerHTML=" passwords did not match";
                    document.getElementById("cnfnewpas").value="";
                    document.getElementById("newpas").value="";
                }
                else{
                    document.getElementById("p2").innerHTML="";
                }
            }
        </script>
        <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float:right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}


</style>
 <script>
            function disappear(){
                document.getElementById("p3").innerHTML="";
            }
        </script>
</head>
<body background='ght.png'>
        <div class="topnav">
                
  <a href="logout.php">LOGOUT</a>
 
   <a href='allimages.php'>SEE ALL IMAGES</a>
   <a href="welcomelogin.php">HOME</a></div><br><br><br><br><br>
    <table align='center' style='color:white;'>
    <form action='cngpas.php' method='post'><p>
        <tr><td style='font-size: 25px'><p id='p3'>PASSWORD COULDN'T BE CHANGED.TRY AGAIN!</p><script>setTimeout("disappear()",3000)</script></td></tr>
        <tr><td style='font-size: 30px'>   old password: <input style='width:200px;height:20px' type='password' name='oldpas' id='oldpas' autofocus required></td></tr>
        <tr><td><br></td></tr>
        <tr><td style='font-size:30px'>    new password:<input type='password' name='newpas' id='newpas' onblur='tes()' style='width:200px;height:20px' required></td></tr>
        <tr><td> <br></td></tr>
        <tr><td><p id='p1'></p></td></tr>
        <tr><td style='font-size:30px'> confrim new password:<input type='password' name='cnfnewpas' id='cnfnewpas' style='width:200px;height:20px' onblur='passcheck()' required></td></tr>
        <tr><td> <br></td></tr>
        <tr><td>    <p id='p2'></p></td></tr>
        <tr><td> <input type='submit' value='change password'></td></tr>
        </p> </form></table>
</body>
</html>



