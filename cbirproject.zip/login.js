
<script>
function testus()
{
var x=document.getElementById("username").value;
var y=/^[^0-9][a-z]{4,20}[0-9]{0,10}\_[a-z]{2,10}[0-9]{0,10}$/;
if(!x.match(y))
{
    document.getElementById("username").style.borderColor="red";
}
}
</script>

