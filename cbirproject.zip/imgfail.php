<?php
session_start();
?>

<html>
    <head>
        <style>
            table {
                align-content: center;
    border-collapse: collapse;
    width: 100%;
}

td {
    text-align: center;
    height: 30px;

}
        </style>
         <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float:right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}


</style>
        <script>
            function disappear(){
                document.getElementById("p1").innerHTML="";
            }
        </script>
    </head>
    <body background="ght.png"><table align='center' style='color:white'>
             <div class="topnav">
                
  <a href="logout.php">LOGOUT</a>
 
   <a href='allimages.php'>SEE ALL IMAGES</a>
   <a href="changedetails.php">CHANGE PASSWORD</a></div>
               <tr><td><br></td></tr>
        <tr><td><?php
         echo "<h1>WELCOME!  ".$_SESSION["username"]."</h1>";
         ?></td></tr><p>
                      <form action="uploadimg.php" method="post" enctype="multipart/form-data">
            <tr>
                <td><h2>select an image to upload:</h2></td>
            </tr>
            <tr>
                <td><input name="image" type="file" style='width:30%;height:100%' ></td>
            </tr>
            
            <tr>
                <td  ><input type="text" name="details" placeholder='detail of image' style='width:30%;height:100%'  requuired></td>
            </tr>
            <tr><td><br></td></tr>
            <tr>
                <td><input type="submit" value="upload" style='width:10%;height:100%' ></td>
            </tr>
            <tr>
                <td><p id="p1" style="font-size:23px;" >image upload failed<br>try again</p></td>
            <script>setTimeout("disappear()",8000)</script>
            </tr>
        </form>
             <tr><td><br></td></tr><tr><td><br></td></tr>
    
        <form action="ret.php" method="post" enctype="multipart/form-data">
            <tr>
                <td><h2>enter the details of image to retrieve</h2></td>
            </tr>

            <tr>
               <td><input type="text" name="details" placeholder='detail of image' style='width:50%;height:130%' required></td>
            </tr>
            <tr><td><br></td></tr>
            <tr>
                <td><input type="submit" value="get image" style='width:10%;height:100%'></td>
            </tr>
        </form>
    </p>
    <tr>
        <td>
            <a style="color:white" href='logout.php'>logout</a>
        </td>
    </tr>
    </table>
    </body>
</html>

